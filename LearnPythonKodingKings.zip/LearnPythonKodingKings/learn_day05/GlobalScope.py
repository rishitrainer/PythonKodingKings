# Global scope
message = "Howdy!"

def say_hello():
    # Local Variables
    global message
    message = "Namaste"
    print("Say Hello Method :: " , message)

say_hello()
print(message)