class Customer:

    def __init__(self, age, gender):
        self.age = age
        self.gender = gender
        print("Customer Init", self.age, self.gender)

    def discount(self):
        print("No Discount for Normal Customers")


class PreferredCustomer(Customer):

    def __init__(self, age, gender, waNumber, email):
        Customer.__init__(self, age, gender)
        self.email = email
        self.mobile = waNumber
        print("PreferredCustomer Init", self.email, self.mobile)

    # Overriding
    def discount(self):
        print("Preferred Customer has 3% Discount")


cust = Customer(21, "M")
cust.discount()
pCust = PreferredCustomer(34, "F", 3432490234, "F@c.com")
pCust.discount()

