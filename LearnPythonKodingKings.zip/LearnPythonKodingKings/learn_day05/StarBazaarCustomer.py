class Customer:

    def __init__(self, age, gender):
        self.age = age
        self.gender = gender
        print("Customer Init", self.age, self.gender)

    def discount(self):
        print("No Discount for Normal Customers")

    def test_method(self):
        print("Test Methods from Customer")


class AddressValidation:

    def __init__(self, address):
        self.address = address
        print("Address Validation Processed for ", self.address)

    def google_maps_validation(self):
        print("Google Maps Validation ", self.address)

    def test_method(self):
        print("Test Methods from AddressValidation")


class PreferredCustomer(Customer, AddressValidation):

    def __init__(self, age, gender, waNumber, email,address):
        Customer.__init__(self, age, gender)
        AddressValidation.__init__(self, address)
        self.email = email
        self.mobile = waNumber
        print("PreferredCustomer Init", self.email, self.mobile)

    # Overriding
    def discount(self):
        print("Preferred Customer has 3% Discount")

    def send_email_coupons(self):
        print("Email sent to ", self.email)


class CreditCardCustomer(PreferredCustomer):

    def __init__(self, age, gender, waNumber, email, address, pan, adhar):
        PreferredCustomer.__init__(self, age, gender, waNumber, email, address)
        self.pan = pan
        self.adhar = adhar
        print("CreditCardCustomer Init", self.pan, self.adhar)

    # Overriding
    def discount(self):
        PreferredCustomer.discount(self)
        print("Credit Card Customer has additional 2% discount")

    def validate_cibil(self):
        print("CIBIL Validation with ", self.pan)


'''
cust = Customer(21, "M")
cust.discount()
pCust = PreferredCustomer(34, "F", 3432490234, "F@c.com")
pCust.discount()
'''
ccCust = CreditCardCustomer(34, "F", 3432490234, "F@c.com", "SOme Address", "oiiweu233s", 324039843924)
ccCust.discount()
ccCust.send_email_coupons()
ccCust.validate_cibil()
ccCust.google_maps_validation()
ccCust.test_method()