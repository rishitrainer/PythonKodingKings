class Employee:

    def __init__(self, empId, empDept):
        self.emp_id = empId
        self.emp_dept = empDept
        print("Employee is created", self.emp_id, self.emp_dept)

    def process_salary(self):
        print("Salary of employee is processed", self.emp_id)


# initializer or constructor
empOne = Employee(1001, "Consultancy")
empOne.process_salary()
empTwo = Employee(2001, "Sales")
empTwo.process_salary()
print(type(empTwo.process_salary)) #  <class 'method'>