# age limit for purchase is 21

age = input("Enter Customer Age:")
state = input("Enter Customer State:")
if age.isdigit():
    int_age = int(age)
    result = int_age >= 21
    print("Result " , result)
    '''
    if condition:
        block of code when condition is true
    else: 
        block of code when condition is false
    '''
    if (int_age >= 21) and (int_age <= 121):
        print("Purchase is Allowed")
    elif state == "FL":
        print("Purchase is Allowed")
    else:
        print("Purchase is NOT Allowed")
else:
    print("Invalid Input Provided")

print("Done!")



