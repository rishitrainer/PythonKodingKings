# Compare 3 numbers with if condition - find the biggest number - no duplicates
first_var = 1000
second_var = 2000
third_var = 300
fourth_var = 400

if(first_var > second_var) and (first_var > third_var):
    print("Greatest is ", first_var)
elif second_var > third_var:
    print("Greatest is ", second_var)
else:
    print("Greatest is ", third_var)


