# mathematical operators + - * / % **
first_var = 100
second_var = 10

print("Addition + ", first_var + second_var)
print("Subtraction - ", first_var - second_var)
print("Multiplication * ", first_var * second_var)
print("Division / ", first_var / second_var)
print("Modulus % ", first_var % second_var)
print("Rest to power ** ", first_var ** 2)

# Comparison operators > < >= <= == !=


