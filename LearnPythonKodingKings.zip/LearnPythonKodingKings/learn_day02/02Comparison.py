# boolean can carry only two values True / False
#test = first_var > second_var
#print(test, type(test))

first_var = 100
second_var = 10

print("Greater than > ", first_var > second_var)
print("Less than < ", first_var < second_var)
print("Greater than or equals >= ", first_var >= second_var)
print("Less than or equals <= ", first_var <= second_var)
print("Equals == ", first_var == second_var)
print("Not Equal != ", first_var != second_var)
