marks = [100, 99, 98, 96, 97]
total_marks = 0

'''
for eachItem in set_of_data:
    Iteration for eachItem
'''
for eachSubject in marks:
    print(eachSubject)
    total_marks = total_marks + eachSubject

print("Total Marks ", total_marks)

# range(startvalue, endvalue, step)
for eachNum in range(0, 11):
    if eachNum % 2 == 1:
        print(eachNum, " is ODD")
        continue
    print(eachNum, "is Even")