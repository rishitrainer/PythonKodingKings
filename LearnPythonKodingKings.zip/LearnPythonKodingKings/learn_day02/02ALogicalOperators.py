# Operates between boolean

first_var = 40
second_var = 200
third_var = 300

S1 = first_var > second_var # true
S2 = first_var > third_var # false

result = S1 and S2
print("AND Result ", result)

'''
S1  S2  Result = S1 and S2
T   T   T
T   F   F
F   T   F
F   F   F
'''

'''
S1  S2  Result = S1 or S2
T   T   T
T   F   T
F   T   T
F   F   F
'''
result = S1 or S2
print("OR Result ", result)

'''
S1  Result = not S1
T   F
F   T
'''
print("Not Result", not result)