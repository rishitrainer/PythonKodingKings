marks = [100, 99, 98, 96, 97]
print(marks[0], marks[1])

# String in Python is Array of Characters
name = "Neil Armstrong"
print(name[0], name[1])
print("Fourth Position", name[4])
print(name)
marks_string = "100, 99, 98, 96, 97"
print(marks_string[10])
age = "121"
print("name.upper() " , name.upper())
print("name.lower() " , name.lower())
print("name.isdigit() " , name.isdigit())
print(name.find("A"))