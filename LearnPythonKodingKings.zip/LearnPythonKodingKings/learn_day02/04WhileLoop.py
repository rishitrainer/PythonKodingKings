# while loop

'''
while condition:
    block of code until condition is true
    condition modifier
Jump out of loop when condition is false.
'''
# Add 1 to 10

count = 1
total = 0
'''
while count <= 10:
    total = total + count
    print(count)
    # Break the loop when count is 5
    if count == 5:
        print("Count is 5, so break the loop")
        break
    count = count + 1
print("Total is ", total)
'''

while count <= 10:
    if count == 5:
        print("Skip 5 from addition")
        count = count + 1
        continue
    total = total + count
    print(count)
    count = count + 1
print("Total is ", total)