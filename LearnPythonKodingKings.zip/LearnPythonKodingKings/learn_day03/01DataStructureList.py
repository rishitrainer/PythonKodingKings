# Lists are written with square brackets.
sampleList = ["apple", "grapes", "oranges", "bananas"]
# Access Items: sampleList[1]
print(sampleList)
print(sampleList[0])
print(sampleList[0:3]) # Sublist
sampleList.append("cranberry")
sampleList.append("cranberry")
print(sampleList)
sampleList.insert(1, "strawberry")
sampleList.insert(1, "strawberry")
sampleList.sort()
print("After Sort :::: " , sampleList)


print(sampleList)
sampleList.remove("cranberry")
print(sampleList)
sampleList.pop(1)
print(sampleList)
del sampleList[0]
print(sampleList)

for eachFruit in sampleList:
    print(eachFruit)

if "grapes" in sampleList:
    print("Grapes are in list")

if "apple" not in sampleList:
    print("Apple is not in List")

sampleList.clear()
print(sampleList)