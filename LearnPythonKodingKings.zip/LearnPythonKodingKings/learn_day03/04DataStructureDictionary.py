# Dictionaries are written in Curly Braces { "Key" : "value"}
sampleDictionary = {
    "company" : "toyota",
    "make" : "Camry",
    "model" : 2020,
    "price" : 20.5,
    "features" : ["central lock", "heated seats", "moon roof",]
}

print(sampleDictionary)
print(sampleDictionary["company"])
sampleDictionary["engine"] = "V8 Diesel Power"
print(sampleDictionary)
sampleDictionary["price"] = 28.5
print(sampleDictionary)

for eachKey in sampleDictionary:
    print(eachKey, sampleDictionary.get(eachKey))

for key, value in sampleDictionary.items():
    print(key, value)

for eachValue in sampleDictionary.values():
    print(eachValue)

# removal
sampleDictionary.pop("make")
print(sampleDictionary)
sampleDictionary.popitem() # remove last inserted entry
print(sampleDictionary)

if 2020 in sampleDictionary.values():
    print("2020 makes are available")

if "features" in sampleDictionary:
    print("We are checking features")

print(len(sampleDictionary))
sampleDictionary.clear()
print(len(sampleDictionary))


# Collection of Keys of Dictionary should be stored in? - Set
# Collection of values of Dictionary should be stored in? - List