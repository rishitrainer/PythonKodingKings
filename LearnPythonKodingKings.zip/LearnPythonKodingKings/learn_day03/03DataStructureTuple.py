# Tuples are written with round brackets.
sampleTuple = ("apple", "grapes", "bananas", "oranges")
print(sampleTuple)
print(sampleTuple[0])

for eachItem in sampleTuple:
    print(eachItem)

if "apple" in sampleTuple:
    print("Apple is present")

print(len(sampleTuple))