'''
def function_name(input:optional):
    indented block of code
    reusable functionality
    return: optional

argument, parameter, input - all the same
'''

def say_hello(pincode=444505, name="User"):
    print("Hello", name, pincode)

say_hello(111000, "David")
say_hello()
