# Sets are written with curly brackets
sampleSet = {"apple", "grapes", "bananas"}

# Add Element:
sampleSet.add("mango")
sampleSet.add("mango")
print(sampleSet)

# remove - gives error if key doesnt exists in Set
sampleSet.remove("apple")
print(sampleSet)
# discard - ignores if key is not present
sampleSet.discard("oranges")
print(sampleSet)

if "mango" in sampleSet:
    print("Mango is present")

if "apple" not in sampleSet:
    print("Apple is not present")

for eachItem in sampleSet:
    print(eachItem)

veggies = {"potatos", "tomatos", "grapes"}
sampleSet.update(veggies)
print(sampleSet)
print(len(sampleSet))

sampleSet.clear()
print(sampleSet)

