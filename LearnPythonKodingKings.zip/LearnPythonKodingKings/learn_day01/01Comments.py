# Single Line Comment
'''
THIS IS CAPITAL COMMENT
'''
"""
This is Called DocStrings - Documentation of Code
"""

