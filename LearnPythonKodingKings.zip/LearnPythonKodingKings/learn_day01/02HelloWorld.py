print("Hello World")
print('This is so easy')
