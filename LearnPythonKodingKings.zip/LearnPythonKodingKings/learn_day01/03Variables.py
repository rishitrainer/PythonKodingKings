age121 = 121
age_customer = 121
_age = 121

age = 21
Age = 22
AGE = 23
percentage = 97.9
company = "KodingKings"
complex_number = 2 + 3j
print(age, Age, AGE)

print(age, type(age), id(age))
print(percentage, type(percentage), id(percentage))
print(company, type(company), id(company))
print(complex_number, type(complex_number), id(complex_number))

# Constructors, Initializers, Casting

customerId = str("0212")
print(customerId, type(customerId))
int_percentage = int(percentage)
print(int_percentage, type(int_percentage))