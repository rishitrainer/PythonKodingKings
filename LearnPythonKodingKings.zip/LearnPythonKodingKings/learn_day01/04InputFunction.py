name = input("Please provide your name:")
print("Hello ", name)