'''
def user_given_name(parameter:optional):
    reusable code
    business logic
    return output : optional
'''
a = 1000
b = 1000
c = 1000
print(id(a), id(b), id(c))


def say_hello(city, name="User!"):
    print("Hello", name, "From ", city)


def addition(*args):
    total = 0
    for eachNumber in args:
        total = total + eachNumber
    print("total ", total)


def validations(**kwargs):
    for eachKey in kwargs:
        print(eachKey, kwargs.get(eachKey))


def test_method(param1, param2, *args, **kwargs):
    print(param1, param2)
    for eachAgrs in args:
        print(eachAgrs)
    for eachKey in kwargs:
        print(eachKey, kwargs.get(eachKey))


say_hello("Chennai", "David")
say_hello("Mumbai", "Roshi")
say_hello("Atlanta", "Neil")
say_hello("India")
say_hello(1000)
say_hello("Mumbai", "India")
# User should be able to pass any number of parameters
addition(10,10)
addition(10,10,10)
addition(10,10,10,10)
addition(10,10,10,10,10)

validations(name="Rishi", address="3375 Spring Hill Road", mobileNumber="9348789347")
test_method(100, 100, "Rishi", "Jayesh", "Sumit", city="Delhi" )