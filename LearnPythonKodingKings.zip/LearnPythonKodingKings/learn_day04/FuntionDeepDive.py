'''
def function_name(input:optional):
    indented block of code
    reusable functionality
    return: optional

argument, parameter, input - all the same
'''
# Default parameter value
def say_hello(city, name="User!"):
    print("Hello", name, "from ", city)


def validate(*args):
    print(type(args))
    for eachValidation in args:
        print("Validation ", eachValidation)


def address_validation(**kwargs):
    print(type(kwargs))
    for eachKey in kwargs:
        print(eachKey, kwargs.get(eachKey))


def test_method(normalparam, *args, **kwargs ):
    print(normalparam)
    for eachValidation in args:
        print("test_method ", eachValidation)
    for eachKey in kwargs:
        print("test_method", eachKey, kwargs.get(eachKey))

say_hello("Mumbai", "David")
say_hello("Atlanta", "Neil")
say_hello("India")
say_hello(1000)
validate("Neil", "Some Address", "neil.armstrong@nasa.com")
address_validation(name="Neil", address="Some Address in USA", email="neil@nasa.com")
test_method(100,"Mumbai", "David", name="Neil", address="Some Address in USA", email="neil@nasa.com" )