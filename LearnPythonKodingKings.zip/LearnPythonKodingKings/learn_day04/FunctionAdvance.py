
def shout(text):
    return str(text).upper()


def calculator(operation, number):
    function_name = None
    def square():
        return number*number

    def cube():
        return number*number*number

    if operation == "square":
        function_name = square
    else:
        function_name = cube

    return function_name


# function is instance of class Function
test_function = shout
print(shout("This is ME"))
print(test_function("This is TEST"))

try_square = calculator("square", 5)
print("Square" , try_square())
try_cube = calculator("cube", 5)
print("Cube" , try_cube())