'''
class ClassName:
    state / propertise
    methods or functions
'''

class Customer:
    name = "Rishi"
    addres = "Something here"

    def discount(self, percent):
        print("Regular Discount for Normal customer", percent)

'''
How to create object of class
userDefinedName = ClassName()
'''
custOne = Customer()
custTwo = Customer()

custTwo.name = "neil"
custTwo.addres = "NASA"

print(custOne.name, custOne.addres)
custOne.discount(6)
print(custTwo.name, custTwo.addres)
custTwo.discount(10)