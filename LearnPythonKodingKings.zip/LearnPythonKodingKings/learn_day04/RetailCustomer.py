'''
class ClassName:
    variables
    functions

objectname = ClassName()
'''

class Customer:
    age = 22
    name = "David"
    gender = "Male"

    def purchase(self):
        print("Purchase by Customer")


custOne = Customer()
custTwo = Customer()

custOne.purchase()
custTwo.age = 42
custTwo.name = "Neil"
custTwo.gender = "Male"

print(custOne.name, custOne.age, custOne.gender)
print(custTwo.name, custTwo.age, custTwo.gender)
