import mysql.connector

myconnection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="password",
    database="kk_python_june21"
)

mycursor = myconnection.cursor()
mycursor.execute("CREATE TABLE customers (name VARCHAR(255), address VARCHAR(255))")

mycursor.close()
myconnection.close()