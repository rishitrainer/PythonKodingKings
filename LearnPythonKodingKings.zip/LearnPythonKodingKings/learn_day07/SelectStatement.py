import mysql.connector

myconnection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="password",
    database="kk_python_june21"
)

mycursor = myconnection.cursor()

# mycursor.execute("SELECT * FROM customers")
sql = "SELECT * FROM customers WHERE address ='Lowstreet 4'"
mycursor.execute(sql)
myresult = mycursor.fetchall()

for eachRow in myresult:
    print(eachRow[0])

mycursor.close()
myconnection.close()