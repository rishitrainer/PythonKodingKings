import mysql.connector

myconnection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="password",
    database="kk_python_june21"
)
sql = "UPDATE customers SET address = 'Canyon 123' WHERE address = 'Valley 345'"
mycursor = myconnection.cursor()
mycursor.execute(sql)
myconnection.commit()
print(mycursor.rowcount, "record(s) affected")


mycursor.close()
myconnection.close()