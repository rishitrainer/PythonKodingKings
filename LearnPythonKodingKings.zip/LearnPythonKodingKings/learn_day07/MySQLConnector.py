import mysql.connector

'''
Name:  Local instance MySQL80 
Host: localhost 
Port: 3306 
Login User: root 
Current User: root@localhost 
SSL cipher: TLS_AES_256_GCM_SHA384
'''

myconnection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="password",
    database="kk_python_june21"
)

mycursor = myconnection.cursor()
print(myconnection)
print(mycursor)
mycursor.execute("CREATE DATABASE kk_python_june21")

mycursor1 = myconnection.cursor()
mycursor1.execute("SHOW DATABASES")

for x in mycursor1:
    print(x)

mycursor1.close()
mycursor.close()
myconnection.close()
