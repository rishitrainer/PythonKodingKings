import mysql.connector

myconnection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="password",
    database="kk_python_june21"
)

mycursor = myconnection.cursor()
sql = "DELETE FROM customers WHERE address = %s"
adr = ('Apple st 652', )
mycursor.execute(sql, adr)
myconnection.commit()

mycursor.close()
myconnection.close()