import mysql.connector

myconnection = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="password",
    database="kk_python_june21"
)
insert_statement = "INSERT INTO customers (name, address) VALUES (%s, %s);"
# val = ("John", "Highway 21")
val = [
    ('Peter', 'Lowstreet 4'),
    ('Amy', 'Apple st 652'),
    ('Hannah', 'Mountain 21'),
    ('Michael', 'Valley 345'),
    ('Sandy', 'Ocean blvd 2'),
    ('Viola', 'Sideway 1633')
]


mycursor = myconnection.cursor()
mycursor.executemany(insert_statement, val)
myconnection.commit()
print(mycursor.rowcount, "record inserted.")
mycursor.close()
myconnection.close()