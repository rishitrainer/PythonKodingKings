file_path = "/RISHI/H2K/FileIO/demofile.txt"
file = open(file_path, "rt") # read only mode and text

# print(file.read(10))

for eachLine in file:
    print("Processing ", eachLine)

file.close()