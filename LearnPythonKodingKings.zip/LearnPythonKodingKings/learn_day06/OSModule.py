import os

file_path = "/RISHI/H2K/FileIO/demofile_kk.txt"

if os.path.exists(file_path):
    print("This File Exists")
else:
    print("This file doesnt exists")

file_path_dir= "/RISHI/H2K/FileIO/KodingKings"

if os.path.exists(file_path_dir):
    print("Do Nothing")
else:
    os.mkdir(file_path_dir)
    print("Directory is created")

# Delete directory or file onspecified path
#os.remove("/RISHI/H2K/FileIO/demofile_new_a.txt")
#print("File removed")

file_list = os.listdir("/RISHI/H2K/FileIO")

for eachFile in file_list:
    print(eachFile)