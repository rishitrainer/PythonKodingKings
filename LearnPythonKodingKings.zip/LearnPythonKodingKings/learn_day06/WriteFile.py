file_path = "/RISHI/H2K/FileIO/demofile_kk.txt"
# w - write - wipe existing content
# a = append - add to existing content
# Both w and a create a file if not exists
file = open(file_path, "a")
file.write("THis is my another new content")

file.close()